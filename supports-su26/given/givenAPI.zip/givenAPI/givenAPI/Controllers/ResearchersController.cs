using givenAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace givenAPI.Controllers;

[ApiController]
[Route("api/researchers")]
public class ResearchersController : ControllerBase
{
    [HttpGet("search")]
    public IActionResult Search([FromQuery] string? name, [FromQuery] string? field)
    {
        var query = DataInitializer.Researchers.AsEnumerable();

        if (!string.IsNullOrWhiteSpace(name))
        {
            query = query.Where(r => r.FullName.Contains(name, StringComparison.OrdinalIgnoreCase));
        }

        if (!string.IsNullOrWhiteSpace(field))
        {
            query = query.Where(r => r.ResearchField.Contains(field, StringComparison.OrdinalIgnoreCase));
        }

        return Ok(query.ToList());
    }

    [HttpGet("{id:int}")]
    public IActionResult GetById(int id)
    {
        var researcher = DataInitializer.Researchers.FirstOrDefault(r => r.ResearcherId == id);
        if (researcher == null)
        {
            return NotFound();
        }

        var paperIds = DataInitializer.PaperAuthors
            .Where(pa => pa.ResearcherId == id)
            .Select(pa => pa.PaperId);

        var papers = DataInitializer.Papers
            .Where(p => paperIds.Contains(p.PaperId))
            .ToList();

        return Ok(new
        {
            researcher.ResearcherId,
            researcher.FullName,
            researcher.ResearchField,
            researcher.JoinDate,
            Papers = papers
        });
    }
}
