namespace givenAPI.Models;

public class Paper
{
    public int PaperId { get; set; }
    public string Title { get; set; } = string.Empty;
    public int PublishYear { get; set; }
}
