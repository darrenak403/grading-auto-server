namespace givenAPI.Models;

public static class DataInitializer
{
    public static List<Researcher> Researchers { get; } = new()
    {
        new Researcher { ResearcherId = 1, FullName = "Dr. Vinh Quang Bui", ResearchField = "Artificial Intelligence", JoinDate = new DateTime(2016, 3, 14) },
        new Researcher { ResearcherId = 2, FullName = "Ms. Lan Thi Ngo", ResearchField = "Data Science", JoinDate = new DateTime(2019, 7, 1) },
        new Researcher { ResearcherId = 3, FullName = "Prof. Thanh Van Hoang", ResearchField = "Biotechnology", JoinDate = new DateTime(2011, 9, 18) },
        new Researcher { ResearcherId = 4, FullName = "Dr. Manh Duc Vu", ResearchField = "Renewable Energy", JoinDate = new DateTime(2020, 4, 22) },
        new Researcher { ResearcherId = 5, FullName = "Ms. Ngan Thi Kim Phan", ResearchField = "Environmental Science", JoinDate = new DateTime(2022, 1, 10) },
    };

    public static List<Paper> Papers { get; } = new()
    {
        new Paper { PaperId = 1, Title = "AI Applications in Medical Diagnosis", PublishYear = 2023 },
        new Paper { PaperId = 2, Title = "Big Data Systems for Online Education", PublishYear = 2022 },
        new Paper { PaperId = 3, Title = "Genetic Analysis of Cancer Inheritance", PublishYear = 2021 },
        new Paper { PaperId = 4, Title = "IoT Applications in Smart Grids", PublishYear = 2024 },
        new Paper { PaperId = 5, Title = "Assessing Water Pollution in the Mekong River", PublishYear = 2020 },
        new Paper { PaperId = 6, Title = "Deep Learning Models for Weather Forecasting", PublishYear = 2023 },
        new Paper { PaperId = 7, Title = "Research on Next-Generation Solar Cells", PublishYear = 2024 },
        new Paper { PaperId = 8, Title = "Microorganisms for Industrial Wastewater Treatment", PublishYear = 2022 },
    };

    public static List<PaperAuthor> PaperAuthors { get; } = new()
    {
        new PaperAuthor { PaperId = 1, ResearcherId = 1 },
        new PaperAuthor { PaperId = 1, ResearcherId = 2 },
        new PaperAuthor { PaperId = 2, ResearcherId = 2 },
        new PaperAuthor { PaperId = 3, ResearcherId = 3 },
        new PaperAuthor { PaperId = 4, ResearcherId = 4 },
        new PaperAuthor { PaperId = 4, ResearcherId = 1 },
        new PaperAuthor { PaperId = 5, ResearcherId = 5 },
        new PaperAuthor { PaperId = 5, ResearcherId = 4 },
        new PaperAuthor { PaperId = 6, ResearcherId = 1 },
        new PaperAuthor { PaperId = 6, ResearcherId = 2 },
        new PaperAuthor { PaperId = 7, ResearcherId = 4 },
        new PaperAuthor { PaperId = 8, ResearcherId = 3 },
    };
}
