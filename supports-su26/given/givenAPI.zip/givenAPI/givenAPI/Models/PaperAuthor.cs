namespace givenAPI.Models;

public class PaperAuthor
{
    public int PaperId { get; set; }
    public int ResearcherId { get; set; }
}
