namespace givenAPI.Models;

public class Researcher
{
    public int ResearcherId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string ResearchField { get; set; } = string.Empty;
    public DateTime JoinDate { get; set; }
}
