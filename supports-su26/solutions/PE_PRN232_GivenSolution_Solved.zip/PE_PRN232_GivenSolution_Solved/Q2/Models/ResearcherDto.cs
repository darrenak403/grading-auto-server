namespace Q2.Models;

public class ResearcherDto
{
    public int ResearcherId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string ResearchField { get; set; } = string.Empty;
    public DateTime JoinDate { get; set; }
}
