namespace Q2.Models;

public class PaperDto
{
    public int PaperId { get; set; }
    public string Title { get; set; } = string.Empty;
    public int PublishYear { get; set; }
}
