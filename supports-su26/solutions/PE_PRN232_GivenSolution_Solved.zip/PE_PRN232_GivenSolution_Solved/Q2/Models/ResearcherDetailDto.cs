namespace Q2.Models;

public class ResearcherDetailDto
{
    public int ResearcherId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string ResearchField { get; set; } = string.Empty;
    public DateTime JoinDate { get; set; }
    public List<PaperDto> Papers { get; set; } = new();
}
