namespace Q2.Models;

public class ResearcherIndexViewModel
{
    public string? Name { get; set; }
    public string? Field { get; set; }
    public List<ResearcherDto> Researchers { get; set; } = new();
}
