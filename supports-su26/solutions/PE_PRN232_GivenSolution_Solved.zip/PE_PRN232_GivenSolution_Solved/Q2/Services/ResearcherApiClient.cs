using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Q2.Models;
using Q2;

namespace Q2.Services;

public class ResearcherApiClient
{
    private readonly HttpClient _httpClient;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public ResearcherApiClient(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<ResearcherDto>> SearchAsync(string? name, string? field)
    {
        string url = Utilities.GetAbsoluteUrl("api/researchers/search");
        string query = "";

        if (!string.IsNullOrWhiteSpace(name))
        {
            query = "name=" + name;
        }
        if (!string.IsNullOrWhiteSpace(field))
        {
            if (query != "") query = query + "&";
            query = query + "field=" + field;
        }
        if (query != "") url = url + "?" + query;

        var researchers = await _httpClient.GetFromJsonAsync<List<ResearcherDto>>(url, JsonOptions);
        return researchers ?? new List<ResearcherDto>();
    }

    public async Task<ResearcherDetailDto?> GetByIdAsync(int researcherId)
    {
        string url = Utilities.GetAbsoluteUrl("api/researchers/" + researcherId);
        var response = await _httpClient.GetAsync(url);

        if (response.StatusCode == HttpStatusCode.NotFound)
        {
            return null;
        }

        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<ResearcherDetailDto>(JsonOptions);
    }
}
