using Q2;
using Q2.Services;

var builder = WebApplication.CreateBuilder(args);

//Initialize UrlUtilities with configuration
//DO NOT change this code
Utilities.Initialize(builder.Configuration);
//End

builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient<ResearcherApiClient>();

var app = builder.Build();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Researcher}/{action=Index}/{researcherId?}");

app.Run();
