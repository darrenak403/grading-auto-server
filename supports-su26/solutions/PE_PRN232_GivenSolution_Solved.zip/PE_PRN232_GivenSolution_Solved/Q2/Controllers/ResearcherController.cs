using Microsoft.AspNetCore.Mvc;
using Q2.Models;
using Q2.Services;

namespace Q2.Controllers;

public class ResearcherController : Controller
{
    private readonly ResearcherApiClient _apiClient;

    public ResearcherController(ResearcherApiClient apiClient)
    {
        _apiClient = apiClient;
    }

    [HttpGet]
    [Route("/Researcher")]
    public async Task<IActionResult> Index(string? name, string? field)
    {
        var researchers = await _apiClient.SearchAsync(name, field);

        var model = new ResearcherIndexViewModel
        {
            Name = name,
            Field = field,
            Researchers = researchers
        };

        return View(model);
    }

    [HttpGet]
    [Route("/Researcher/{researcherId:int}")]
    public async Task<IActionResult> Details(int researcherId)
    {
        var researcher = await _apiClient.GetByIdAsync(researcherId);
        if (researcher == null)
        {
            return NotFound();
        }

        return View(researcher);
    }
}
