using Microsoft.EntityFrameworkCore;
using Q1.Models;

namespace Q1.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Researcher> Researchers => Set<Researcher>();
    public DbSet<Journal> Journals => Set<Journal>();
    public DbSet<Paper> Papers => Set<Paper>();
    public DbSet<PaperAuthor> PaperAuthors => Set<PaperAuthor>();
    public DbSet<Topic> Topics => Set<Topic>();
    public DbSet<PaperTopic> PaperTopics => Set<PaperTopic>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<PaperAuthor>().HasKey(pa => new { pa.PaperID, pa.ResearcherID });
        modelBuilder.Entity<PaperTopic>().HasKey(pt => new { pt.PaperID, pt.TopicID });

        modelBuilder.Entity<PaperAuthor>()
            .HasOne(pa => pa.Paper)
            .WithMany(p => p.PaperAuthors)
            .HasForeignKey(pa => pa.PaperID);

        modelBuilder.Entity<PaperAuthor>()
            .HasOne(pa => pa.Researcher)
            .WithMany(r => r.PaperAuthors)
            .HasForeignKey(pa => pa.ResearcherID);

        modelBuilder.Entity<PaperTopic>()
            .HasOne(pt => pt.Paper)
            .WithMany(p => p.PaperTopics)
            .HasForeignKey(pt => pt.PaperID);

        modelBuilder.Entity<PaperTopic>()
            .HasOne(pt => pt.Topic)
            .WithMany(t => t.PaperTopics)
            .HasForeignKey(pt => pt.TopicID);

        modelBuilder.Entity<Paper>()
            .HasOne(p => p.Journal)
            .WithMany(j => j.Papers)
            .HasForeignKey(p => p.JournalID);
    }
}
