namespace Q1.Dtos;

public class JournalDto
{
    public int JournalId { get; set; }
    public string JournalName { get; set; } = string.Empty;
    public double? ImpactFactor { get; set; }
    public int PaperCount { get; set; }
}
