namespace Q1.Dtos;

public class PaperFilterDto
{
    public int PaperId { get; set; }
    public string Title { get; set; } = string.Empty;
    public int? PublishYear { get; set; }
    public int CitationCount { get; set; }
    public string? JournalName { get; set; }
    public string LeadAuthor { get; set; } = "No Author";
    public List<string> TopicList { get; set; } = new();
}
