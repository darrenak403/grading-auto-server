namespace Q1.Dtos;

public class PaperCreateDto
{
    public string Title { get; set; } = string.Empty;
    public int? PublishYear { get; set; }
    public int? JournalID { get; set; }
}
