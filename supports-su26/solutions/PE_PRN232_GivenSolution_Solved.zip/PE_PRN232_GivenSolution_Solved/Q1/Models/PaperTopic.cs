namespace Q1.Models;

public class PaperTopic
{
    public int PaperID { get; set; }
    public int TopicID { get; set; }

    public Paper? Paper { get; set; }
    public Topic? Topic { get; set; }
}
