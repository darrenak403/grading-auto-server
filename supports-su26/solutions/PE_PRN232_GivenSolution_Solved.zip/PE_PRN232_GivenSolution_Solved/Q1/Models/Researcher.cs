namespace Q1.Models;

public class Researcher
{
    public int ResearcherID { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string? ResearchField { get; set; }
    public DateTime? JoinDate { get; set; }

    public ICollection<PaperAuthor> PaperAuthors { get; set; } = new List<PaperAuthor>();
}
