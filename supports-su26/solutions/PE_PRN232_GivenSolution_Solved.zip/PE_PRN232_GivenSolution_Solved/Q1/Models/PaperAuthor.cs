namespace Q1.Models;

public class PaperAuthor
{
    public int PaperID { get; set; }
    public int ResearcherID { get; set; }

    public Paper? Paper { get; set; }
    public Researcher? Researcher { get; set; }
}
