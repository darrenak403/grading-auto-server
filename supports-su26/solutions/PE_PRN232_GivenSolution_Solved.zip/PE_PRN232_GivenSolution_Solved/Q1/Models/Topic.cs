namespace Q1.Models;

public class Topic
{
    public int TopicID { get; set; }
    public string TopicName { get; set; } = string.Empty;

    public ICollection<PaperTopic> PaperTopics { get; set; } = new List<PaperTopic>();
}
