namespace Q1.Models;

public class Paper
{
    public int PaperID { get; set; }
    public string Title { get; set; } = string.Empty;
    public int? PublishYear { get; set; }
    public int? JournalID { get; set; }
    public int CitationCount { get; set; }

    public Journal? Journal { get; set; }
    public ICollection<PaperAuthor> PaperAuthors { get; set; } = new List<PaperAuthor>();
    public ICollection<PaperTopic> PaperTopics { get; set; } = new List<PaperTopic>();
}
