namespace Q1.Models;

public class Journal
{
    public int JournalID { get; set; }
    public string JournalName { get; set; } = string.Empty;
    public double? ImpactFactor { get; set; }

    public ICollection<Paper> Papers { get; set; } = new List<Paper>();
}
