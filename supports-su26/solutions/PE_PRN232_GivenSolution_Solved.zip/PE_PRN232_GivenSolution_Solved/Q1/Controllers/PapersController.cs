using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Q1.Data;
using Q1.Dtos;
using Q1.Models;

namespace Q1.Controllers;

[ApiController]
[Route("api")]
public class PapersController : ControllerBase
{
    private readonly AppDbContext _db;

    public PapersController(AppDbContext db)
    {
        _db = db;
    }

    [HttpGet("filter-papers")]
    public async Task<IActionResult> FilterPapers([FromQuery] string? topic, [FromQuery] int? minCitations)
    {
        if (minCitations.HasValue && minCitations.Value < 0)
        {
            return BadRequest("minCitations must not be negative");
        }

        var query = _db.Papers.AsQueryable();

        if (!string.IsNullOrWhiteSpace(topic))
        {
            query = query.Where(p => p.PaperTopics.Any(pt => pt.Topic!.TopicName.ToLower() == topic.ToLower()));
        }

        if (minCitations.HasValue)
        {
            query = query.Where(p => p.CitationCount >= minCitations.Value);
        }

        var result = await query
            .OrderByDescending(p => p.CitationCount)
            .Select(p => new PaperFilterDto
            {
                PaperId = p.PaperID,
                Title = p.Title,
                PublishYear = p.PublishYear,
                CitationCount = p.CitationCount,
                JournalName = p.Journal != null ? p.Journal.JournalName : null,
                LeadAuthor = p.PaperAuthors
                    .OrderBy(pa => pa.ResearcherID)
                    .Select(pa => pa.Researcher!.FullName)
                    .FirstOrDefault() ?? "No Author",
                TopicList = p.PaperTopics.OrderBy(pt => pt.TopicID).Select(pt => pt.Topic!.TopicName).ToList()
            })
            .ToListAsync();

        return Ok(result);
    }

    [HttpPost("papers")]
    public async Task<IActionResult> CreatePaper([FromBody] PaperCreateDto dto)
    {
        var exists = await _db.Papers.AnyAsync(p => p.Title == dto.Title);
        if (exists)
        {
            return BadRequest("Paper title already exists");
        }

        var paper = new Paper
        {
            Title = dto.Title,
            PublishYear = dto.PublishYear,
            JournalID = dto.JournalID,
            CitationCount = 0
        };

        _db.Papers.Add(paper);
        await _db.SaveChangesAsync();

        return StatusCode(201, new
        {
            paperId = paper.PaperID,
            title = paper.Title,
            publishYear = paper.PublishYear,
            journalId = paper.JournalID,
            citationCount = paper.CitationCount,
            paperAuthors = Array.Empty<object>(),
            paperTopics = Array.Empty<object>(),
            journal = (object?)null
        });
    }

    [HttpDelete("papers/{paperId:int}")]
    public async Task<IActionResult> DeletePaper(int paperId)
    {
        var paper = await _db.Papers.FindAsync(paperId);
        if (paper == null)
        {
            return NotFound();
        }

        var hasAuthors = await _db.PaperAuthors.AnyAsync(pa => pa.PaperID == paperId);
        if (hasAuthors)
        {
            return BadRequest("Cannot delete paper with assigned authors");
        }

        _db.Papers.Remove(paper);
        await _db.SaveChangesAsync();

        return NoContent();
    }
}
