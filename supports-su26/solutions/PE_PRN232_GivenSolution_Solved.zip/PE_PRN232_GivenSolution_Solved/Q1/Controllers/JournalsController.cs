using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Q1.Data;
using Q1.Dtos;

namespace Q1.Controllers;

[ApiController]
[Route("api")]
public class JournalsController : ControllerBase
{
    private readonly AppDbContext _db;

    public JournalsController(AppDbContext db)
    {
        _db = db;
    }

    [HttpGet("journals")]
    public async Task<ActionResult<List<JournalDto>>> GetJournals()
    {
        var journals = await _db.Journals
            .OrderBy(j => j.JournalID)
            .Select(j => new JournalDto
            {
                JournalId = j.JournalID,
                JournalName = j.JournalName,
                ImpactFactor = j.ImpactFactor,
                PaperCount = j.Papers.Count
            })
            .ToListAsync();

        return Ok(journals);
    }
}
